﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp.Tests
{
	class Program
	{
		static void Main(string[] args)
		{
			Example1_13.HiddenFunction();
		}
	}
}
