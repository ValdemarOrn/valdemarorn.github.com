﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;

namespace DarkSideOfCSharp
{
	public class Example3_4
	{
		public static void Example()
		{
			// we have to declare val in safe code because trying to
			// pass unsafe values to Console.Writeline makes you program freak out
			// with access violations and other crazy exceptions
			int val = 0;

			unsafe
			{
				// allocate memory on the heap
				int* arrPtr = (int*)Marshal.AllocHGlobal(100 * 4);

				int i = 0;

				// Fill array with 2*i
				while (i < 100)
				{
					*(arrPtr + 4 * i) = i * 2;
					i++;
				}

				i = 0;
				while (i < 100)
				{
					val = *(arrPtr + 4 * i);
					Console.WriteLine(val.ToString()); // Prints 0 2 4 6 ... 198
					i++;
				}

				int k = 23;
			}
		}
	}
}
