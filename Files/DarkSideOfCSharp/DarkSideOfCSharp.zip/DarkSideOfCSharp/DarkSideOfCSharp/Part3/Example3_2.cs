﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;

namespace DarkSideOfCSharp
{
	public class Example3_2
	{
		// to get currently active window
		[DllImport("user32.dll", CallingConvention = CallingConvention.StdCall)]
		private static extern IntPtr GetForegroundWindow();

		// Get the title text of a window
		// We can use StringBuilder where the dll expects char* , it is automatically handled for us
		[DllImport("user32.dll", CallingConvention = CallingConvention.StdCall)]
		private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

		public static void Example()
		{
			string text = "";

			while (true)
			{
				IntPtr windowHandle = GetForegroundWindow();
				StringBuilder buffer = new StringBuilder(256);
				GetWindowText(windowHandle, buffer, 256);
				if (text != buffer.ToString())
				{
					text = buffer.ToString();
					Console.WriteLine(text);
				}
				Thread.Sleep(100);
			}
		}
	}
}
