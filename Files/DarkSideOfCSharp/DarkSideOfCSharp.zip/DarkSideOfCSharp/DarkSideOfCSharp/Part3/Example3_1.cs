﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace DarkSideOfCSharp
{
	public class Example3_1
	{
		public static int[][][] MakeData()
		{
			int[][][] Map = new int[10][][];

			for (int x = 0; x < 10; x++)
			{
				Map[x] = new int[10][];
				for (int y = 0; y < 10; y++)
				{
					Map[x][y] = new int[10];
					for (int z = 0; z < 10; z++)
					{
						Map[x][y][z] = x + y + z;
					}
				}
			}

			return Map;
		}

		public static void Example()
		{
			int[][][] Map = MakeData();
			int x = 0;
			int y = 0;
			int z = 0;

			for(x=0; x < 10; x++)
				for (y = 0; y < 10; y++)
					for (z = 0; z < 10; z++)
						if(Map[x][y][z] == 25)
							goto End;

		End:
			Console.WriteLine("Found 25 at " + x + "," + y + "," + z);

		}
	}
}
