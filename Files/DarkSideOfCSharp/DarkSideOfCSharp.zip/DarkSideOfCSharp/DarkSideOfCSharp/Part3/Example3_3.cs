﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;

namespace DarkSideOfCSharp
{
	public class Example3_3
	{
		public static void Example()
		{
			decimal Verðbólguspá = 12.5M; // totally legal!
		}
	}
}
