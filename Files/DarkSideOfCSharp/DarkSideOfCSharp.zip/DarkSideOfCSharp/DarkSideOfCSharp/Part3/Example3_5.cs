﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;

namespace DarkSideOfCSharp
{
	public class Example3_5
	{
		public static IEnumerable<Tuple<string, byte[]>> GetFiles(string directory)
		{
			var files = Directory.GetFiles(directory);
			foreach (var file in files)
			{
				var fi = new FileInfo(file);
				if (fi.Length > 1024 * 1024 * 20) // skip files larger than 20 meg
					continue;

				var content = File.ReadAllBytes(file);
				yield return new Tuple<string, byte[]>(file, content);
			}
		}

		public static void Example()
		{
			string path = @"C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\IDE";

			// let's count all the zero bytes in every file in the directory
			// We can offload the work of opening and reading files to another method, GetFiles()
			// Without using generators we have to load every file into memory. Too much data, not enough memory!
			// instead, we use a generator to yield one file at a time
			foreach (var file in GetFiles(path))
			{
				int count = file.Item2.Count(x => x == 0);
				Console.WriteLine("File " + file.Item1 + " contains " + count + " zero bytes");
			}
		}
	}
}
