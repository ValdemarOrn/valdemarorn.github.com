﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp
{
	public class Example1_11
	{
		int _val;
		public int OldStyleValue
		{
			get { return _val; }
			set { _val = value; }
		}

		// NewStyle has the backing field automatically implemented by the compiler
		public int NewStyle { get; set; }

		// You can even define different access modifiers for get and set
		public static int DifferentAccessor { get; private set; }

		public static void Example()
		{
			DifferentAccessor = 42; // only assignable inside this class
		}
	}
}
