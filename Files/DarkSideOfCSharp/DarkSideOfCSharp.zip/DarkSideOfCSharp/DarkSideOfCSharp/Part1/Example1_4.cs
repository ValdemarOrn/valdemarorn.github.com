﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp
{
	public delegate void LogDelegate(string logString);

	public class BusinessClass
	{
		// We provide a delegate property that can be assigned to at runtime
		public LogDelegate Log { get; set; }

		public void DoWork()
		{ 
			// ...Do some work inside this method...

			// Call the Log delegate
			Log("Some information");

			// ...Continue working...
		}
	}

	public class Example1_4
	{
		public static void Example()
		{
			var business = new BusinessClass();
			business.Log = ConsoleLogger;
			business.DoWork(); // This will print text in the console

			business.Log = FileLogger;
			business.DoWork(); // This will write text to file
		}

		public static void ConsoleLogger(string text) { Console.WriteLine(text); }

		public static void FileLogger(string text) { System.IO.File.WriteAllText(@"c:\logfile.txt", text); }
	}
}
