﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp
{
	public class Example1_3
	{
		public static void Example()
		{
			int? valueA = 5;
			int? valueB = null;

			int valueC = valueA ?? 42; // ValueC becomes 5
			int valueD = valueB ?? 42; // ValueD becomes 42
			int valueE = (valueB != null) ? (int)valueB : 42; // not as pretty!
		}
	}
}
