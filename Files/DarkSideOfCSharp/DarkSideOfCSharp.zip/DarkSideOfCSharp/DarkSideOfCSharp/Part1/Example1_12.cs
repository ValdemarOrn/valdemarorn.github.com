﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp
{
	// This is a custom Attribute. We can use it to find
	// special fields in our class. We use the attribute to
	// filter out which fields to log and which to skip over
	public class LogAttribute : Attribute
	{
		public string Field;

		public LogAttribute(string logField)
		{
			Field = logField;
		}
	}

	public class Entity
	{
		public int Value; // Don't log this field

		[Log("Text Message")]
		public string Text;
		
		[Log("@")]
		public DateTime Time;
	}

	public class Example1_12
	{
		public static void Example()
		{
			var e = new Entity();
			e.Text = "Some text";
			e.Time = DateTime.Now;
			e.Value = 56;

			// Writes "Text Message: Some text @: 20.9.2012 01:12:01" to the console
			LogToConsole(e);
		}

		public static void LogToConsole(object obj)
		{
			// We use reflection to get information about the class of the object
			// what fields the class contains, and what attributes those fields have
			var fields = obj.GetType().GetFields();
			foreach (var field in fields)
			{
				var attr = field.GetCustomAttributes(typeof(LogAttribute), true);
				if (attr.Length > 0)
					Console.Write(((LogAttribute)attr[0]).Field + ": " + field.GetValue(obj) + " ");
			}
			Console.Write("\n");
		}
	}
}
