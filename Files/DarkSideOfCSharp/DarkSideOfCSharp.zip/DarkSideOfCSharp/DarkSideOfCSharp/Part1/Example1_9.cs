﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp
{
	public class Example1_9
	{
		public static void Example()
		{
			#if DEBUG

			// #warning shows up in Visual Studio's Error List
			//#warning DEBUG is defined. Test code has been enabled

			// You can use this for assertions, tracing and logging and it will
			// automatically be removed when building in release configuration
			Console.WriteLine("This statement only runs in Debug Configuration");
			#endif
		}
	}
}
