﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp
{
	public class Example1_10
	{
		public static void Example()
		{
			OldMethod();
		}


		[Obsolete]
		public static void OldMethod()
		{ 
		
		}
	}
}
