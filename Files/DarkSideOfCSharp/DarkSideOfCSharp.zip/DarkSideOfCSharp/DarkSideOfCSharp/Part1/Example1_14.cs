﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DarkSideOfCSharp
{
	public class Config
	{
		public static string DatabaseName {get; private set; }
		public static string Hostname { get; private set; }
		public static int TimeoutMillisec { get; private set; }

		// this is a static constructor. It will run before any field, property or method
		// in this class is accessed.
		static Config()
		{
			DatabaseName = "Localhost:1234";
			Hostname = "mycomputer.domain.com";
			TimeoutMillisec = 1200;
		}
	}

	public class Example1_14
	{
		public static void Example()
		{
			string db = Config.DatabaseName; // db = "Localhost:1234"
			string host = Config.Hostname; // host = "mycomputer.domain.com"
			int timeout = Config.TimeoutMillisec; // timeout = 1200
		}
	}
}
