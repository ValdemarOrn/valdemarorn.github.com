﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp
{
	/*public class Person
	{
		public string Name;
		public int Age;
		public string Occupation;
	}*/

	public class Example1_5
	{
		public static void Example()
		{
			// Create a simple dataset
			var list = new List<Person>();
			list.Add(new Person() { Name = "John", Age = 24, Occupation = "Programmer" });
			list.Add(new Person() { Name = "Michelle", Age = 55, Occupation = "Manager" });
			list.Add(new Person() { Name = "Alex", Age = 31, Occupation = "Programmer" });
			list.Add(new Person() { Name = "Jack", Age = 96, Occupation = "Retired" });
			list.Add(new Person() { Name = "Audrey", Age = 13, Occupation = "Student" });
			list.Add(new Person() { Name = "Lucas", Age = 17, Occupation = "Student" });

			// search the set using Linq syntax
			var students = from p in list where p.Occupation == "Student" select p.Name;
			var programmers = from p in list where p.Occupation == "Programmer" select p.Name;
			var kids = from p in list where p.Age < 18 select p.Name;
		}
	}
}
