﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp
{
	public class User
	{
		public string Username;
		public string Password;
		public int Age;
	}

	public class Example1_1
	{
		public static void Example()
		{
			var user = new User() { Username = "John", Password = "god123", Age = 24 };
		}
	}
}
