﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp
{
	public class Person
	{
		public string Name;
		public int Age;
		public string Occupation;
	}

	public class Example1_8
	{
		public static void Example()
		{
			// Create a simple dataset
			var list = new List<Person>();
			list.Add(new Person() { Name = "John", Age = 24, Occupation = "Programmer" });
			list.Add(new Person() { Name = "Michelle", Age = 63, Occupation = "Butcher" });
			list.Add(new Person() { Name = "Alex", Age = 31, Occupation = "Programmer" });
			list.Add(new Person() { Name = "Jack", Age = 96, Occupation = "Retired" });
			list.Add(new Person() { Name = "Audrey", Age = 13, Occupation = "Student" });
			list.Add(new Person() { Name = "Lucas", Age = 17, Occupation = "Student" });

			// Find all people over 30, take their names and concatename them into a string, seperated by commas
			string names = list.Where(x => x.Age > 30).Select(x => x.Name).Aggregate((x, y) => x + ", " + y);
			Console.WriteLine(names); // Prints "Michelle, Alex, Jack"
		}
	}
}
