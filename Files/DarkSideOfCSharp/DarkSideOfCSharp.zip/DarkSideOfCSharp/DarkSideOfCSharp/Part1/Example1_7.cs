﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp
{
	public class Example1_7
	{
		public static void Example()
		{
			var array = new int[] { 23, 12, 5, 0, 16, 83, 56, 42 };
			bool containsZero = array.Any(x => x == 0); // True

			var text = new List<string>() { "Albert", "John", "Mike", "Jessica", "Lucas" };
			var firstJ = text.First(x => x.StartsWith("J")); // John
			var alphabetical = text.OrderBy(x => x).ToList(); // order the list alphabetically
		}
	}
}
