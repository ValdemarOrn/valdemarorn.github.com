﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp
{
	public class Example1_2
	{
		public static void Example()
		{
			// DateTime data1 = null;  -- Compiler Error!
			int? data2 = null; // Works

			if (!data2.HasValue)
				Console.WriteLine("data2 has no value!"); // Statement will be executed

			// Another way to declare a nullable object
			Nullable<DateTime> date3 = DateTime.Now;

			// The proper way to access the value
			Console.WriteLine(date3.Value.ToShortDateString());

			// You can also use a cast
			Console.WriteLine(((DateTime)date3).ToShortDateString());

			// This causes an Exception at runtime!
			Console.WriteLine("Value of data2: " + ((int)data2));
		}
	}
}
