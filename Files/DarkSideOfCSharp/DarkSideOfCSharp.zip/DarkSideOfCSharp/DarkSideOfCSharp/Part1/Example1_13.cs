﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Runtime.CompilerServices;
[assembly:InternalsVisibleTo("DarkSideOfCSharp.Tests")]

namespace DarkSideOfCSharp
{
	public class Example1_13
	{
		internal static void HiddenFunction()
		{
			Console.WriteLine("This function can normally only be accessed from inside this assembly");
		}
	}
}
