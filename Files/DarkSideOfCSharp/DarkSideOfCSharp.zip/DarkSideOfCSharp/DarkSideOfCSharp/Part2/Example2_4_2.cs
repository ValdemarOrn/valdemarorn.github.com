﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DarkSideOfCSharp
{
	public delegate bool MyDele2(int val);

	public class Example2_4_2
	{
		public static void Example()
		{
			// create an anonymous function without using lambda syntax
			// Does the same thing as Example 2.4.2
			MyDele2 dele = delegate(int x)
			{
				if (x % 5 == 0)
					return true;
				else
					return false;
			};

			Console.WriteLine("7 is a multiple of 5: " + dele(7)); // "False"
			Console.WriteLine("10 is a multiple of 5: " + dele(10)); // "True"
		}
	}
}
