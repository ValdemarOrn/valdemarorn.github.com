﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace DarkSideOfCSharp
{
	public class Example2_7
	{
		public static void Example()
		{
			// create an object of an anonymous type
			var anon = new { Name = "Valdemar", Age = 24 };

			// But really, there's always a type; the compiler just hides it away
			// Prints "<>f__AnonymousType0`2[System.String,System.Int32]"
			Console.WriteLine(anon.GetType().ToString());

			// anonymous objects are statically typed.
			// You even get intellisense in Visual Studio
			Console.WriteLine("Name: " + anon.Name);

			//... but they're read-only!
			//anon.Name = "John"; // Compiler error!
		}
	}
}
