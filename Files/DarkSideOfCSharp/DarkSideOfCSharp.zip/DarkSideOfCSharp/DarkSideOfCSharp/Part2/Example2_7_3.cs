﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace DarkSideOfCSharp
{
	public class Example2_7_3
	{
		public static List<T> CreateAnonList<T>(T prototype)
		{
			return new List<T>();
		}

		public static void Example()
		{
			var anon1 = new { Name = "Valdemar", Age = 24 };
			var anon2 = new { Name = "John", Age = 56 };

			// Use the anonymous type as a "prototype"
			// we can infer its type and create a list of that type!
			var anonList = CreateAnonList(anon1);

			anonList.Add(anon1);
			anonList.Add(anon2);
		}
	}
}
