﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace DarkSideOfCSharp
{
	public class Log
	{
		public static void Time(Action action)
		{
			var start = DateTime.Now;
			action();
			var millis = (DateTime.Now - start).TotalMilliseconds;
			Console.WriteLine("Action took " + millis + " milliseconds");
		}
	}

	public class Example2_6
	{
		public static void Example()
		{
			// how long does it take to sum all numbers between 0 and 100000000??
			Log.Time(() =>
			{
				ulong x = 0;
				for (int i = 0; i < 100000000; i++ )
					x = x + (ulong)i;
			});

			// Console shows "Action took 314,0179 milliseconds"
			Console.ReadLine();
		}
	}
}
