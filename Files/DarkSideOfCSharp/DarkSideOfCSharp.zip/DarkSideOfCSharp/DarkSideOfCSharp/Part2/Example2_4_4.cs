﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DarkSideOfCSharp
{
	// Define a delegate type that returns a value that is a function
	public delegate Func<int, bool> FactoryDele(int x);

	public class Example2_4_4
	{
		public static void Example()
		{
			// Define a function which returns another function
			FactoryDele functionFactory = x => ( val => val % x == 0 );

			Func<int, bool> divisibleBy5 = functionFactory(5);
			Func<int, bool> divisibleBy3 = functionFactory(3);

			Console.WriteLine("7 is a divisible of 5: " + divisibleBy5(7)); // "False"
			Console.WriteLine("10 is a divisible of 5: " + divisibleBy5(10)); // "True"

			Console.WriteLine("7 is a divisible of 3: " + divisibleBy3(7)); // "False"
			Console.WriteLine("9 is a divisible of 3: " + divisibleBy3(9)); // "True"
		}
	}
}
