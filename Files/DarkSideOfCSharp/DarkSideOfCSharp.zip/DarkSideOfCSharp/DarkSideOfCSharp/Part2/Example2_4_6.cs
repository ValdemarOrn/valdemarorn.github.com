﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace DarkSideOfCSharp
{
	public class Example2_4_6
	{
		public static void Example()
		{
			var form = new Form();

			var button1 = new Button();
			button1.Text = "Click 1";
			button1.Top = 10;
			var button2 = new Button();
			button2.Text = "Click 2";
			button2.Top = 50;

			// Define an event handler that shows a message box
			button1.Click += delegate(object sender, EventArgs e) { 
				MessageBox.Show("You clicked 1"); 
			};

			// Alternative way to accomplish the same thing using lambda syntax
			button2.Click += (sender, e) => MessageBox.Show("You clicked 2");

			form.Controls.Add(button1);
			form.Controls.Add(button2);
			form.ShowDialog();
		}
	}
}
