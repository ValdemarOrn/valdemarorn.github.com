﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp
{
	// Extension methods must be declared inside static classes
	public static class MyExtensions
	{
		// Note the "this" keyword before the first parameter. This is how you
		// make an method behave like an extension method
		public static int Index<T>(this List<T> list, Func<T, bool> expression)
		{
			for (int i = 0; i < list.Count; i++)
			{
				if (expression(list[i]))
					return i;
			}

			return -1;
		}
	}

	public class Example2_1
	{
		public static void Example()
		{
			var list = new List<string>() { "John", "Mike", "Jessica", "Christina", "Michelle" };
			int indexOfM = list.Index(x => x.StartsWith("M")); // returns 1
		}
	}
}
