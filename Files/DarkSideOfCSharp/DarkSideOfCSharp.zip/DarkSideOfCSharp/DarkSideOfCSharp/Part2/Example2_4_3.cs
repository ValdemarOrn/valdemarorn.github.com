﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DarkSideOfCSharp
{
	public class Example2_4_3
	{
		public static void Example()
		{
			// instead of having to define out own delegate with the correct signature
			// we can use the type Func<T,TResult>, which was introduced in .NET 3.5
			Func<int, bool> dele = x => (x % 5 == 0);

			Console.WriteLine("7 is a multiple of 5: " + dele(7)); // "False"
			Console.WriteLine("10 is a multiple of 5: " + dele(10)); // "True"

			// Func<> takes 0...4 inputs and returns an output
			// if your function returns void then we can use Action<> instead
			Action<string> printIt = x => Console.WriteLine(x);

			printIt("Hello World"); // prints "Hello World" to the console
		}
	}
}
