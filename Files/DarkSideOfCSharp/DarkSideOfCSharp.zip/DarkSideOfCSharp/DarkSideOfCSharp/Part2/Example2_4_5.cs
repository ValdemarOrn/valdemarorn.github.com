﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DarkSideOfCSharp
{
	public class Example2_4_5
	{
		public static void Example()
		{
			var list = new List<int>() { 2, 3, 5, 9, 12, 14 };
			bool anyDivisableBy7 = list.Any(Expression); // anyDivisableBy7 = true
		}

		public static bool Expression(int x)
		{
			return (x % 7 == 0);
		}
	}
}
