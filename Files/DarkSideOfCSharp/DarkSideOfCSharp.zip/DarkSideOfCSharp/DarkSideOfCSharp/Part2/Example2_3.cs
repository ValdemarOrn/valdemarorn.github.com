﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DarkSideOfCSharp
{
	public class Human
	{
		public string Name;
		public int Age;

		// This is not a very bright idea...
		public static implicit operator int(Human h) { return h.Age; }
		public static implicit operator string(Human h) { return h.Age.ToString(); /* WTF mate!!? */ }
	}

	public class Example2_3
	{
		public static void Example()
		{
			var human = new Human() { Name = "Valdemar", Age = 24 };
			int intValue = human; // intValue = 24
			string stringValue = human; // stringValue = "24" !

			// You thought casting Human to string would give you the Name?
			// See how easy it is to abuse and confuse you code with bad implicit conversions!!
			// Use with caution!
		}
	}
}
