﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace DarkSideOfCSharp
{
	public class Example2_5
	{
		public static void Example()
		{
			Action[] actions = null;

			Action make = delegate ()
			{
				// this anonymous function forms a closure
				// From here we can access variables declared outside this function
				actions = new Action[5];

				// but we can also declare variables that exist inside this closure
				int i = 1;

				// This probably doesn't do what you think...
				for (; i <= 5; i++)
					actions[i - 1] = () => Console.WriteLine("i is " + i);
			};

			make();

			// Call all the methods
			for (int i = 0; i < 5; i++)
				actions[i]();
		}
	}
}
