﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkSideOfCSharp
{
	// Define a "Pair" type as a Tuple of an int and a string
	using Pair = Tuple<int, string>;

	// Define PairList as a List of Pairs
	using PairList = List<Tuple<int, string>>;

	public class Example2_2
	{
		public static void Example()
		{
			// Create a new PairList
			PairList list = new PairList();
			
			// Add Pair objects into the list
			list.Add(new Pair(23, "Hello World"));
			list.Add(new Pair(56, "More Text"));

			// Prints
			// System.Collections.Generic.List`1[System.Tuple`2[System.Int32,System.String]]
			Console.WriteLine(list.GetType().ToString());
		}
	}
}
