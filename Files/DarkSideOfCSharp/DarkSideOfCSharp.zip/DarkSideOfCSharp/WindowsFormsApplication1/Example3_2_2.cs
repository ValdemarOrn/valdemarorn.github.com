﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace WindowsFormsApplication1
{
	public class Example3_2_2
	{
		[DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
		static extern bool FreeConsole();

		[DllImport("kernel32.dll")]
		static extern bool AllocConsole();

		public static void Example()
		{
			var form = new Form();

			var button1 = new Button();
			button1.Text = "Show console";
			button1.Top = 10;
			var button2 = new Button();
			button2.Text = "Hide Console";
			button2.Top = 50;
			var button3 = new Button();
			button3.Text = "Print time";
			button3.Top = 100;

			// Alternative way to accomplish the same thing using lambda syntax
			button1.Click += (sender, e) => AllocConsole();
			button2.Click += (sender, e) => FreeConsole();
			button3.Click += (sender, e) => 
				Console.WriteLine("Debug message @ " + DateTime.Now.ToLongTimeString());

			form.Controls.Add(button1);
			form.Controls.Add(button2);
			form.Controls.Add(button3);
			form.ShowDialog();
		}
	}
}
