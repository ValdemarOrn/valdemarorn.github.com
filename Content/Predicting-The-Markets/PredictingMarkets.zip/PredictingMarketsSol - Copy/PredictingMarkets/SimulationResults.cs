﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PredictingMarkets
{
	public class SimulationResults
	{
		public List<double> MarketPortfolio { get; set; }
		public List<double> AlphaPortfolio { get; set; }

		public List<double> MarketReturn { get; set; }
		public List<double> AlphaReturn { get; set; }

		public double MarketPortfolioReturn { get { return (MarketPortfolio.Last() - MarketPortfolio.First()) / MarketPortfolio.First(); } }
		public double AlphaPortfolioReturn { get { return (AlphaPortfolio.Last() - AlphaPortfolio.First()) / AlphaPortfolio.First(); } }

		public bool BeatTheMarket { get { return AlphaPortfolio.Last() > MarketPortfolio.Last(); } }

		public double ComputeReturnsMarket(bool isSelfFinancing, bool annualized)
		{
			return ComputeReturns(MarketPortfolioReturn, MarketReturn.Count, isSelfFinancing, annualized);
		}

		public double ComputeReturnsAlpha(bool isSelfFinancing, bool annualized)
		{
			return ComputeReturns(AlphaPortfolioReturn, AlphaReturn.Count, isSelfFinancing, annualized);
		}

		public double ComputeIrMarket(bool isSelfFinancing, bool annualized)
		{
			return ComputeIr(MarketReturn, MarketPortfolioReturn, isSelfFinancing, annualized);
		}

		public double ComputeIrAlpha(bool isSelfFinancing, bool annualized)
		{
			return ComputeIr(AlphaReturn, AlphaPortfolioReturn, isSelfFinancing, annualized);
		}

		private double ComputeReturns(double portfolioReturn, int periods, bool isSelfFinancing, bool annualized)
		{
			var periodsOutput = annualized ? ForecastingTest.PeriodsAnnually : periods;

			if (isSelfFinancing)
			{
				var perPeriod = Math.Pow(1 + portfolioReturn, 1.0 / periods) - 1.0;
				var output = Math.Pow(1 + perPeriod, periodsOutput) - 1.0;
				return output;
			}
			else
			{
				var output = portfolioReturn / periods * periodsOutput;
				return output;
			}
		}

		private double ComputeIr(IList<double> returns, double portfolioReturn, bool isSelfFinancing, bool annualized)
		{
			var periods = returns.Count;
			var periodsOutput = annualized ? ForecastingTest.PeriodsAnnually : periods;
			var adjustedReturns = ComputeReturns(portfolioReturn, periods, isSelfFinancing, annualized);

			var mu = returns.Average();
			var variance = returns.Select(x => Math.Pow(x - mu, 2)).Sum() / periods;
			var perPeriodSigma = Math.Sqrt(variance); // per-period sigma
			var adjustedSigma = perPeriodSigma * Math.Sqrt(periodsOutput);
			return adjustedReturns / adjustedSigma;
		}
	}
}
