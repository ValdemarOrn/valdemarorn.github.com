﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using LowProfile.Visuals;
using MathNet.Numerics.Distributions;
using MathNet.Numerics.Random;
using OxyPlot;

namespace PredictingMarkets
{
	public class ForecastingTest
	{
		public const int PeriodsAnnually = 250;

		public static int TrialCount;
		public static int NumSecurities;
		public static int Periods;
		public static double PredictionRate;
		public static double BasePortfolioValue;
		public static bool SelfFinancing;
		public static bool ShowAnnualizedStats;
		public static double AssetStdDev;

		public void Run()
		{
			SimulateMultiple();
			Console.ReadLine();
		}

		private void SimulateMultiple()
		{
			var allResults = new List<SimulationResults>();
			int i = 0;
			Parallel.For(0, TrialCount, _ =>
			{
				var dataSingleRun = SimulateMarket(i);
				lock (allResults)
				{
					Console.WriteLine("Done computing {0} portfolio", Interlocked.Increment(ref i));
					allResults.Add(dataSingleRun);
				}
			});

			var marketReturn = allResults.Select(x => x.ComputeReturnsMarket(SelfFinancing, ShowAnnualizedStats)).Average();
			var alphaReturn = allResults.Select(x => x.ComputeReturnsAlpha(SelfFinancing, ShowAnnualizedStats)).Average();
			
			var marketIr = allResults.Select(x => x.ComputeIrMarket(SelfFinancing, ShowAnnualizedStats)).Average();
			var alphaIr = allResults.Select(x => x.ComputeIrAlpha(SelfFinancing, ShowAnnualizedStats)).Average();

			Console.WriteLine("Average Market Return {0:0.00}%, Average Market IR {1:0.00}",
				marketReturn * 100,
				marketIr);

			Console.WriteLine("Average Alpha Return {0:0.00}%, Average Alpha IR {1:0.00}",
				alphaReturn * 100,
				alphaIr);

			Console.WriteLine("Beat the market: {0:0.00}%",
				allResults.Count(x => x.BeatTheMarket) / (double)allResults.Count * 100);
			
			var data = allResults.First();
			
			var pm = new PlotModel();
			pm.AddLine(data.MarketPortfolio, new OxyPlotHelper.LineStyle { Color = OxyColors.Black, Thickness = 1.0 });
			pm.AddLine(data.AlphaPortfolio, new OxyPlotHelper.LineStyle { Color = OxyColors.Orange, Thickness = 1.0 });
			pm.Show(1200, 800, true);
		}

		private SimulationResults SimulateMarket(int seed = 0)
		{
			var rand = new CryptoRandomSource();
			var returns = CreateReturns(seed);
			var marketReturns = returns.Item1;
			var assetReturns = returns.Item2;

			var marketPortfolio = BasePortfolioValue;
			var alphaPortfolio = BasePortfolioValue;
			var marketPortfolioTimeseries = new List<double> { marketPortfolio };
			var alphaPortfolioTimeseries = new List<double> { alphaPortfolio };
			var alphaReturns = new List<double>();

			for (int n = 0; n < Periods; n++)
			{
				var initValueMarket = SelfFinancing ? marketPortfolio : BasePortfolioValue;
				var initValueAlpha = SelfFinancing ? alphaPortfolio : BasePortfolioValue;

				// Market return
				var marketReturn = initValueMarket * marketReturns[n];
				marketPortfolio += marketReturn;

				// Alpha return
				// we use the numActiveSecurities in Part 2, to filter out stocks that are inactive on the day
				var numActiveSecurities = assetReturns.Count(x => x[n] != 0.0);
				var perSecurityExposure = initValueAlpha / numActiveSecurities;
				var totalClose = 0.0;
				for (int i = 0; i < NumSecurities; i++)
				{
					var assetReturn = assetReturns[i];
					if (assetReturn[n] == 0.0)
						continue; // skip inactive securities

					var prediction = GetPrediction(assetReturn, n, rand);
					var closePos = perSecurityExposure * (1 + assetReturn[n] * prediction);
					totalClose += closePos;
				}
				var alphaReturn = totalClose - initValueAlpha;

				alphaReturns.Add(alphaReturn / initValueAlpha);
				alphaPortfolio += alphaReturn;

				marketPortfolioTimeseries.Add(marketPortfolio);
				alphaPortfolioTimeseries.Add(alphaPortfolio);
			}

			return new SimulationResults
			{
				MarketPortfolio = marketPortfolioTimeseries,
				AlphaPortfolio = alphaPortfolioTimeseries,

				MarketReturn = marketReturns.ToList(),
				AlphaReturn = alphaReturns
			};
		}

		protected virtual Tuple<double[], double[][]> CreateReturns(int seed)
		{
			var rand = new CryptoRandomSource();
			var normalGenerator = new Normal(0.00, AssetStdDev, rand);

			var assetReturns = new double[NumSecurities][];
			var marketReturns = new double[Periods];

			for (int i = 0; i < NumSecurities; i++)
			{
				var returns = new double[Periods];
				normalGenerator.Samples(returns);
				assetReturns[i] = returns;
			}

			// the market is the average of all the securities' returns
			for (int n = 0; n < Periods; n++)
			{
				marketReturns[n] = assetReturns.Select(returns => returns[n]).Average();
			}

			return Tuple.Create(marketReturns, assetReturns);
		}

		private int GetPrediction(double[] assetReturn, int period, Random rand)
		{
			var predictAccurately = rand.NextDouble() < PredictionRate;

			if (predictAccurately)
			{
				return assetReturn[period] > 0 ? 1 : -1;
			}
			else
			{
				return rand.NextDouble() < 0.5 ? 1 : -1;
			}
		}
	}
}
