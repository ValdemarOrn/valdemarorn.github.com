﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using LowProfile.Visuals;
using MathNet.Numerics.Distributions;
using MathNet.Numerics.Random;
using OxyPlot;

namespace PredictingMarkets
{
	public class Program
	{
		[STAThread]
		public static void Main(string[] args)
		{
			Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
			CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;

			ForecastingTest.TrialCount = 1;
			ForecastingTest.NumSecurities = 100;
			ForecastingTest.Periods = 250;
			ForecastingTest.PredictionRate = 0.05;
			ForecastingTest.BasePortfolioValue = 1000.0;
			ForecastingTest.SelfFinancing = true;
			ForecastingTest.ShowAnnualizedStats = false;
			ForecastingTest.AssetStdDev = 0.01;

			// Code to generate the sine charts
			SimulateMean(100, 1000);

			new ForecastingTest().Run();
		}

		private static void SimulateMean(int signalLen, int signalCount)
		{
			var rand = new CryptoRandomSource();
			var normalGenerator = new Normal(0.00, 1.0, rand);
			var signal = Enumerable.Range(0, signalLen).Select(x => Math.Sin(x / 10.0)).ToArray();
			var noisySignals = new List<double[]>();

			for (int i = 0; i < signalCount; i++)
			{
				var noise = new double[signalLen];
				normalGenerator.Samples(noise);
				var noisySignal = signal.Zip(noise.Select(x => x * 10), (a, b) => a + b).ToArray();
				noisySignals.Add(noisySignal);
			}

			var combinedSignal = Enumerable.Range(0, signalLen).Select(x => noisySignals.Select(y => y[x]).Average()).ToArray();

			var pm = new PlotModel();
			pm.AddLine(combinedSignal, new OxyPlotHelper.LineStyle { Color = OxyColors.Black, Thickness = 1.0 });
			pm.Show(1200, 800, true);
		}
	}
}
