﻿using System;
using System.Globalization;
using System.IO;
using System.Threading;
using PredictingMarkets;

namespace PredictingRealMarkets
{
	public class Program
	{
		[STAThread]
		public static void Main(string[] args)
		{
			Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
			CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;

			ForecastingTest.TrialCount = 10;
			ForecastingTest.NumSecurities = int.MaxValue;
			ForecastingTest.PredictionRate = 0.05;
			ForecastingTest.BasePortfolioValue = 1000.0;
			ForecastingTest.SelfFinancing = true;
			ForecastingTest.ShowAnnualizedStats = true;
			
			RealForecastingTest.TempDir = Path.Combine(Environment.CurrentDirectory, "Temp");
			RealForecastingTest.MinDate = new DateTime(2004, 1, 1);
			RealForecastingTest.MaxDate = new DateTime(2014, 12, 31);

			new RealForecastingTest().Run();
		}
	}
}
