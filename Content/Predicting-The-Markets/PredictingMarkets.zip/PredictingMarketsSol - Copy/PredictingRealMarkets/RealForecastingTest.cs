﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using PredictingMarkets;

namespace PredictingRealMarkets
{
	public class RealForecastingTest : ForecastingTest
	{
		/// <summary>
		/// Source: https://en.wikipedia.org/wiki/List_of_S%26P_500_companies
		/// </summary>
		public string[] Sp500 = { "MMM", "ABT", "ABBV", "ACN", "ACE", "ADBE", "ADT", "AAP", "AES", "AET", "AFL", "AMG", "A", "GAS", "APD", "ARG", "AKAM", 
									"AA", "AGN", "ALXN", "ALLE", "ADS", "ALL", "ALTR", "MO", "AMZN", "AEE", "AAL", "AEP", "AXP", "AIG", "AMT", "AMP", 
									"ABC", "AME", "AMGN", "APH", "APC", "ADI", "AON", "APA", "AIV", "AAPL", "AMAT", "ADM", "AIZ", "T", "ADSK", "ADP",
									"AN", "AZO", "AVGO", "AVB", "AVY", "BHI", "BLL", "BAC", "BK", "BCR", "BXLT", "BAX", "BBT", "BDX", "BBBY", "BRK-B",
									"BBY", "BIIB", "BLK", "HRB", "BA", "BWA", "BXP", "BSX", "BMY", "BRCM", "BF-B", "CHRW", "CA", "CVC", "COG", "CAM", 
									"CPB", "COF", "CAH", "HSIC", "KMX", "CCL", "CAT", "CBG", "CBS", "CELG", "CNP", "CTL", "CERN", "CF", "SCHW", "CHK", 
									"CVX", "CMG", "CB", "CI", "XEC", "CINF", "CTAS", "CSCO", "C", "CTXS", "CLX", "CME", "CMS", "COH", "KO", "CCE", "CTSH", 
									"CL", "CPGX", "CMCSA", "CMA", "CSC", "CAG", "COP", "CNX", "ED", "STZ", "GLW", "COST", "CCI", "CSX", "CMI", "CVS", "DHI", 
									"DHR", "DRI", "DVA", "DE", "DLPH", "DAL", "XRAY", "DVN", "DO", "DFS", "DISCA", "DISCK", "DG", "DLTR", "D", "DOV", "DOW",
									"DPS", "DTE", "DD", "DUK", "DNB", "ETFC", "EMN", "ETN", "EBAY", "ECL", "EIX", "EW", "EA", "EMC", "EMR", "ENDP", "ESV", 
									"ETR", "EOG", "EQT", "EFX", "EQIX", "EQR", "ESS", "EL", "ES", "EXC", "EXPE", "EXPD", "ESRX", "XOM", "FFIV", "FB", "FAST",
									"FDX", "FIS", "FITB", "FSLR", "FE", "FISV", "FLIR", "FLS", "FLR", "FMC", "FTI", "F", "FOSL", "BEN", "FCX", "FTR", "GME",
									"GPS", "GRMN", "GD", "GE", "GGP", "GIS", "GM", "GPC", "GNW", "GILD", "GS", "GT", "GOOGL", "GOOG", "GWW", "HAL", "HBI", 
									"HOG", "HAR", "HRS", "HIG", "HAS", "HCA", "HCP", "HCN", "HP", "HES", "HPQ", "HD", "HON", "HRL", "HSP", "HST", "HCBK", 
									"HUM", "HBAN", "ITW", "IR", "INTC", "ICE", "IBM", "IP", "IPG", "IFF", "INTU", "ISRG", "IVZ", "IRM", "JEC", "JBHT", "JNJ",
									"JCI", "JOY", "JPM", "JNPR", "KSU", "K", "KEY", "GMCR", "KMB", "KIM", "KMI", "KLAC", "KSS", "KHC", "KR", "LB", "LLL", "LH",
									"LRCX", "LM", "LEG", "LEN", "LVLT", "LUK", "LLY", "LNC", "LLTC", "LMT", "L", "LOW", "LYB", "MTB", "MAC", "M", "MNK", "MRO",
									"MPC", "MAR", "MMC", "MLM", "MAS", "MA", "MAT", "MKC", "MCD", "MHFI", "MCK", "MJN", "WRK", "MDT", "MRK", "MET", "KORS",
									"MCHP", "MU", "MSFT", "MHK", "TAP", "MDLZ", "MON", "MNST", "MCO", "MS", "MOS", "MSI", "MUR", "MYL", "NDAQ", "NOV", "NAVI",
									"NTAP", "NFLX", "NWL", "NFX", "NEM", "NWSA", "NEE", "NLSN", "NKE", "NI", "NBL", "JWN", "NSC", "NTRS", "NOC", "NRG", "NUE",
									"NVDA", "ORLY", "OXY", "OMC", "OKE", "ORCL", "OI", "PCAR", "PLL", "PH", "PDCO", "PAYX", "PYPL", "PNR", "PBCT", "POM", "PEP", 
									"PKI", "PRGO", "PFE", "PCG", "PM", "PSX", "PNW", "PXD", "PBI", "PCL", "PNC", "RL", "PPG", "PPL", "PX", "PCP", "PCLN", "PFG",
									"PG", "PGR", "PLD", "PRU", "PEG", "PSA", "PHM", "PVH", "QRVO", "PWR", "QCOM", "DGX", "RRC", "RTN", "O", "RHT", "REGN", "RF",
									"RSG", "RAI", "RHI", "ROK", "COL", "ROP", "ROST", "RCL", "R", "CRM", "SNDK", "SCG", "SLB", "SNI", "STX", "SEE", "SRE", "SHW",
									"SIAL", "SIG", "SPG", "SWKS", "SLG", "SJM", "SNA", "SO", "LUV", "SWN", "SE", "STJ", "SWK", "SPLS", "SBUX", "HOT", "STT",
									"SRCL", "SYK", "STI", "SYMC", "SYY", "TROW", "TGT", "TEL", "TE", "TGNA", "THC", "TDC", "TSO", "TXN", "TXT", "HSY", "TRV", 
									"TMO", "TIF", "TWX", "TWC", "TJX", "TMK", "TSS", "TSCO", "RIG", "TRIP", "FOXA", "TSN", "TYC", "USB", "UA", "UNP", "UNH", "UPS",
									"URI", "UTX", "UHS", "UNM", "URBN", "VFC", "VLO", "VAR", "VTR", "VRSN", "VZ", "VRTX", "VIAB", "V", "VNO", "VMC", "WMT", "WBA", 
									"DIS", "WM", "WAT", "ANTM", "WFC", "WDC", "WU", "WY", "WHR", "WFM", "WMB", "WEC", "WYN", "WYNN", "XEL", "XRX", "XLNX", "XL", 
									"XYL", "YHOO", "YUM", "ZBH", "ZION", "ZTS" };

		public static string TempDir;
		public static DateTime MinDate;
		public static DateTime MaxDate;

		private readonly Dictionary<string, Dictionary<DateTime, double>> allReturns;
		private readonly Tuple<double[], double[][]> marketData;

		public RealForecastingTest()
		{
			Sp500 = Sp500.OrderBy(x => x).ToArray();
			NumSecurities = NumSecurities > Sp500.Length ? Sp500.Length : NumSecurities;
			Directory.CreateDirectory(TempDir);
			allReturns = GetAllReturns();
			marketData = CreateRealMarket();
		}

		protected override Tuple<double[], double[][]> CreateReturns(int seed)
		{
			return marketData;
		}

		private Tuple<double[], double[][]> CreateRealMarket()
		{
			var daysOfTrading = allReturns
				.SelectMany(x => x.Value.Keys)
				.Distinct()
				.Where(x => x >= MinDate && x <= MaxDate)
				.OrderBy(x => x)
				.ToArray();

			Periods = daysOfTrading.Length;
			var assetReturns = new double[NumSecurities][];
			var marketReturns = new double[Periods];

			for (int i = 0; i < NumSecurities; i++)
			{
				var symbol = Sp500[i];
				var returnsByDay = allReturns[symbol];
				var returns = new double[Periods];

				for (int n = 0; n < daysOfTrading.Length; n++)
				{
					var date = daysOfTrading[n];
					double ret;
					var ok = returnsByDay.TryGetValue(date, out ret);
					if (!ok)
						ret = 0.0;
					returns[n] = ret;
				}

				assetReturns[i] = returns;
			}

			// the market is the average of all the securities' returns that were trading that day.
			// Skip any securities with a return of exactly zero, assume those were not trading
			for (int n = 0; n < Periods; n++)
			{
				var returnsOnDate = assetReturns.Select(returns => returns[n]);
				var activeReturns = returnsOnDate.Where(x => x != 0.0);
				marketReturns[n] = activeReturns.Average();
			}

			return Tuple.Create(marketReturns, assetReturns);
		}

		private Dictionary<string, Dictionary<DateTime, double>> GetAllReturns()
		{
			var allSecurities = Sp500.AsParallel()
				.WithDegreeOfParallelism(6)
				.Select(symbol => new
				{
					Symbol = symbol, 
					Return = GetReturns(symbol)
				})
				.ToDictionary(x => x.Symbol, x => x.Return);

			return allSecurities;
		}

		private string[] GetCsvData(string symbol)
		{
			var from = new DateTime(2000, 1, 1);
			var to = DateTime.Today.AddDays(-2);

			var url = @"http://real-chart.finance.yahoo.com/table.csv?s=" + symbol +
				string.Format("&a={0}&b={1}&c={2}&d={3}&e={4}&f={5}&g=d&ignore=.csv",
					from.Month - 1,
					from.Day,
					from.Year,
					to.Month - 1,
					to.Day,
					to.Year);
			
			var file = Path.Combine(TempDir, symbol + ".csv");

			try
			{
				if (!File.Exists(file))
				{
					Console.WriteLine("Fetching data for {0}", symbol);
					var text = GetText(url);
					File.WriteAllText(file, text);
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Could not download {0}. {1}", symbol, ex.Message);
				return null;
			}

			return File.ReadAllLines(file);
		}

		private Dictionary<DateTime, double> GetReturns(string symbol)
		{
			var csvLines = GetCsvData(symbol);

			var data = csvLines
				.Select(x => x.Split(','))
				.Skip(1) // Skip the header
				.Select(x => new PriceData
				{
					Date = DateTime.Parse(x[0]), 
					Open = double.Parse(x[1]),
					High = double.Parse(x[2]),
					Low = double.Parse(x[3]),
					Close = double.Parse(x[4]),
					Volume = double.Parse(x[5]),
					AdjustedClose = double.Parse(x[6])
				})
				.ToArray();

			var returns = PriceDataToReturns(data);
			return returns;
		}

		private static Dictionary<DateTime, double> PriceDataToReturns(IEnumerable<PriceData> data)
		{
			var returns = new Dictionary<DateTime, double>();
			var prices = data.OrderBy(x => x.Date).ToArray();
			var prevPrice = prices.First().AdjustedClose;

			for (int i = 1; i < prices.Length; i++)
			{
				var price = prices[i];
				var ret = (price.AdjustedClose - prevPrice) / prevPrice;
				returns[price.Date] = ret;
				prevPrice = price.AdjustedClose;
			}

			return returns;
		}

		private static string GetText(string url)
		{
			var webRequest = WebRequest.Create(url);
			using (var response = webRequest.GetResponse())
			using (var content = response.GetResponseStream())
			{
				// Yahoo seems to close the stream as soon as you read the last byte, this doesn't jive well with the streamreader
				// so we have to resort to this.
				var buffer = new byte[1024 * 1024 * 2];
				var totalData = new List<byte>();
				while (true)
				{
					var length = content.Read(buffer, 0, buffer.Length);
					if (length == 0)
						break;

					totalData.AddRange(buffer.Take(length));
				}
				var strContent = Encoding.UTF8.GetString(totalData.ToArray(), 0, totalData.Count);
				return strContent;
			}
		}

		private class PriceData
		{
			public DateTime Date { get; set; }
			public double Open { get; set; }
			public double High { get; set; }
			public double Low { get; set; }
			public double Close { get; set; }
			public double Volume { get; set; }
			public double AdjustedClose { get; set; }
		}
	}
}
